// Server-side proxy to Sunbird AI. Keeps credentials off the phone.
// Env vars (Netlify > Site settings > Environment): SUNBIRD_USERNAME + SUNBIRD_PASSWORD  (or SUNBIRD_TOKEN)
const B = 'https://api.sunbird.ai';
const OK = ['lug', 'eng', 'swa', 'kin', 'nyn', 'ach'];
let tok = null, exp = 0;
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json' } });
async function token() {
  if (process.env.SUNBIRD_TOKEN) return process.env.SUNBIRD_TOKEN;
  if (tok && Date.now() < exp) return tok;
  const r = await fetch(B + '/auth/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ username: process.env.SUNBIRD_USERNAME || '', password: process.env.SUNBIRD_PASSWORD || '' }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || !d.access_token) throw new Error('auth');
  tok = d.access_token; exp = Date.now() + 6 * 864e5; // tokens last 7 days
  return tok;
}
const configured = () => !!(process.env.SUNBIRD_TOKEN || (process.env.SUNBIRD_USERNAME && process.env.SUNBIRD_PASSWORD));
export default async (req) => {
  const route = new URL(req.url).pathname.replace(/^\/(\.netlify\/functions\/)?api\/?/, '');
  if (route === 'health') return json({ engine: configured() });
  if (req.method !== 'POST' || !configured()) return json({ error: 'unavailable' }, 503);
  try {
    const auth = { Authorization: 'Bearer ' + await token() };
    let up;
    if (route === 'translate') {
      const { from, to, text } = await req.json();
      if (!OK.includes(from) || !OK.includes(to) || !text || text.length > 500) return json({ error: 'bad request' }, 400);
      up = await fetch(B + '/tasks/translate', { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_language: from, target_language: to, text }) });
    } else if (route === 'stt') {
      const f = await req.formData(); const audio = f.get('audio'); const language = String(f.get('language') || '');
      if (!audio || !OK.includes(language) || audio.size > 8e6) return json({ error: 'bad request' }, 400);
      const fd = new FormData(); fd.append('audio', audio, 'speech.webm'); fd.append('language', language);
      up = await fetch(B + '/tasks/audio/transcriptions', { method: 'POST', headers: auth, body: fd });
    } else if (route === 'tts') {
      const { text, language } = await req.json();
      if (!OK.includes(language) || !text || text.length > 400) return json({ error: 'bad request' }, 400);
      up = await fetch(B + '/tasks/audio/speech', { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, language, response_mode: 'stream' }) });
      return new Response(up.body, { status: up.status, headers: { 'Content-Type': up.headers.get('content-type') || 'audio/wav' } });
    } else return json({ error: 'not found' }, 404);
    return new Response(up.body, { status: up.status, headers: { 'Content-Type': 'application/json' } });
  } catch (e) { return json({ error: 'upstream' }, 502); }
};
export const config = { path: '/api/*' };
