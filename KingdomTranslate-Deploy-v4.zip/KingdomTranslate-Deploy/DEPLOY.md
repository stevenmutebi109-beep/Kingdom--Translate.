# Kingdom Translate – Deploy (v4)

Drag-and-drop does NOT run the server function. Use GitHub or the CLI:

1. Put this folder in a GitHub repo, then Netlify > Add new site > Import from Git (publish dir ".", leave build empty)
   OR: `npm i -g netlify-cli && netlify deploy --prod --dir=.`
2. Sign up at https://api.sunbird.ai/register, verify your email, copy your token from https://api.sunbird.ai/keys,
   then in Netlify > Site configuration > Environment variables add SUNBIRD_TOKEN = that token.
   (Alternative: SUNBIRD_USERNAME = your sign-up email and SUNBIRD_PASSWORD; the function fetches tokens itself.)
3. Open the site on your phone > Install. Header badge says "AI online" when the engine is connected,
   "Phrasebook" when offline or not configured.

Without step 2 the app still works as an offline Luganda <-> English phrasebook.
Have a native Luganda speaker review the phrasebook before public use.
